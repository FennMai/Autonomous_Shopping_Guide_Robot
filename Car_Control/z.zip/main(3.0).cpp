#include "CarControl.hpp"
#include <iostream>
#include <functional>

using std::cout;
using std::endl;

void onMovementComplete() {
    cout << "Movement complete." << endl;
}

int main() {
    CarControl car;
    car.initialize();
    
    cout << "Moving forward 10 cm." << endl;
    car.moveForward(10.0, onMovementComplete);
    
    cout << "Moving backward 10 cm." << endl;
    car.moveBackward(10.0, onMovementComplete);
    
    cout << "Turning right 90 degrees." << endl;
    car.turnRight(90, onMovementComplete);
    
    cout << "Turning left 90 degrees." << endl;
    car.turnLeft(90, onMovementComplete);
    
    cout << "Stopping car." << endl;
    car.stop();  // This may not require a callback as it's an immediate action.
    
    cout << "Test sequence complete." << endl;
    
    car.cleanup();
    return 0;
}
